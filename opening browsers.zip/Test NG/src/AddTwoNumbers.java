
public class AddTwoNumbers {
public static void main(String[] args){
	int num1= 1045;
	int num2= 2000;
	int num3 = num1+num2;
	System.out.println(num3);
}
}
