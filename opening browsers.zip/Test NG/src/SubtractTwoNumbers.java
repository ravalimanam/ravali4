
public class SubtractTwoNumbers 
 {
	public static void main(String[] args){
		
		System.out.println("the program accepts two numbers from command line");
		System.out.println("Number1:"+args[0]);
		System.out.println("Number2:"+args[1]);
		int number1 = Integer.parseInt(args[0]);
		int number2 =Integer.parseInt(args[1]);
		int diff  = number1 - number2 ;
		System.out.println(" difference : "+ diff );
		
			
	}

}
