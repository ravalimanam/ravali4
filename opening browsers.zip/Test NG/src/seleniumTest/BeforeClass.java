package seleniumTest;

public @interface BeforeClass {

}
