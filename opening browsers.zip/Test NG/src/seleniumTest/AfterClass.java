package seleniumTest;

public @interface AfterClass {

}
