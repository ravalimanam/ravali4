package seleniumTest;

import org.junit.Test;

public class Class1 {
	@BeforeClass
	public static void login(){
		System.out.println("login succesful");
	}
	@AfterClass
	public static void logout(){
		System.out.println("logout successful");
		
	}
	@Test
	public static void search(){
		System.out.println("search successful");
	}
	@Test
	public static void buyproduct(){
		System.out.println("buying product successful");
	}
	@Test
	public static void advancedsearch(){
		System.out.println("advanced search successful ");
	}

}
