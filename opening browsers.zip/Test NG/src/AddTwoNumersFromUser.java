
public class AddTwoNumersFromUser {

}
